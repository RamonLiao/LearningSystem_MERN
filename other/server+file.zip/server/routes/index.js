module.exports = {
  auth: require("./auth"),
  course: require("./course-route"),
};
